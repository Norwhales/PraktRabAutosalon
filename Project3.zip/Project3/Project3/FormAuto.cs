﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project3
{
    public partial class FormAuto : Form
    {
        public FormAuto()
        {
            InitializeComponent();
        }

        private void ForPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnReg_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormReg formReg = new FormReg();
            formReg.Show();
        }

        private void Авторизация_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void BtnEnter1_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnect = new SqlConnection("Data Source=172.16.0.211\\SQLEXPRESS;Initial Catalog=user29;Persist Security Info=True;User ID=user29;Password=wsruser29");

            sqlConnect.Open();
            SqlCommand sqlQuery = new SqlCommand("SELECT * FROM [dbo].[User] Where Login='" + TxtBLogin.Text + "' And Password='" + TxtBPassword.Text + "'", sqlConnect);

            SqlDataReader sqlQueryReader = null;
            sqlQueryReader = sqlQuery.ExecuteReader();
            if (sqlQueryReader.HasRows)
            {
                sqlQueryReader.Read();

                if ((sqlQueryReader.GetValue(0).ToString() == TxtBLogin.Text) &&
                    (sqlQueryReader.GetValue(1).ToString() == TxtBPassword.Text))
                {
                    if (sqlQueryReader.GetValue(2).ToString() == "Director")
                    {
                        MessageBox.Show("Вы авторизовались за менеджера))))))))");

                    }
                    else if (sqlQueryReader.GetValue(2).ToString() == "Client")
                    {

                        FormUser formU = new FormUser();
                        formU.Show();

                    }

                }
                else MessageBox.Show("Неправильно введён логин или пароль");
            }
        }

        private void BtnOKKK_Click(object sender, EventArgs e)
        {
           
        }
    }
}
