﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class FormReg : Form
    {
        public FormReg()
        {
            InitializeComponent();
        }

        private void FormReg_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void FormReg_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            FormAuto formAuto = new FormAuto();
            formAuto.Show();
        }

        private void FormReg_Load(object sender, EventArgs e)
        {

        }
    }
}
