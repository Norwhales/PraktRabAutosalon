﻿namespace Project3
{
    partial class FormReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPass = new System.Windows.Forms.Label();
            this.LblLog = new System.Windows.Forms.Label();
            this.TxtBLogin = new System.Windows.Forms.TextBox();
            this.TxtBPassword = new System.Windows.Forms.TextBox();
            this.Name = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblPass
            // 
            this.LblPass.AutoSize = true;
            this.LblPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPass.Location = new System.Drawing.Point(86, 230);
            this.LblPass.Name = "LblPass";
            this.LblPass.Size = new System.Drawing.Size(82, 20);
            this.LblPass.TabIndex = 11;
            this.LblPass.Text = "Password:";
            // 
            // LblLog
            // 
            this.LblLog.AutoSize = true;
            this.LblLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblLog.Location = new System.Drawing.Point(86, 174);
            this.LblLog.Name = "LblLog";
            this.LblLog.Size = new System.Drawing.Size(52, 20);
            this.LblLog.TabIndex = 10;
            this.LblLog.Text = "Login:";
            // 
            // TxtBLogin
            // 
            this.TxtBLogin.Location = new System.Drawing.Point(88, 197);
            this.TxtBLogin.Name = "TxtBLogin";
            this.TxtBLogin.Size = new System.Drawing.Size(246, 20);
            this.TxtBLogin.TabIndex = 9;
            // 
            // TxtBPassword
            // 
            this.TxtBPassword.Location = new System.Drawing.Point(88, 253);
            this.TxtBPassword.Name = "TxtBPassword";
            this.TxtBPassword.Size = new System.Drawing.Size(246, 20);
            this.TxtBPassword.TabIndex = 8;
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name.Location = new System.Drawing.Point(88, 288);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(55, 20);
            this.Name.TabIndex = 13;
            this.Name.Text = "Name:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(88, 311);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(246, 20);
            this.textBox1.TabIndex = 12;
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BtnOk.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BtnOk.ForeColor = System.Drawing.SystemColors.Desktop;
            this.BtnOk.Location = new System.Drawing.Point(254, 399);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(80, 29);
            this.BtnOk.TabIndex = 14;
            this.BtnOk.Text = "Ok";
            this.BtnOk.UseVisualStyleBackColor = false;
            // 
            // FormReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 465);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LblPass);
            this.Controls.Add(this.LblLog);
            this.Controls.Add(this.TxtBLogin);
            this.Controls.Add(this.TxtBPassword);
        //    this.Name = "FormReg";
            this.Text = "FormReg";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormReg_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormReg_FormClosed);
            this.Load += new System.EventHandler(this.FormReg_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPass;
        private System.Windows.Forms.Label LblLog;
        private System.Windows.Forms.TextBox TxtBLogin;
        private System.Windows.Forms.TextBox TxtBPassword;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BtnOk;
    }
}