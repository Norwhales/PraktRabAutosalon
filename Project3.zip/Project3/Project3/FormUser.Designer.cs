﻿namespace Project3
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.JstTxt = new System.Windows.Forms.Label();
            this.Perspect = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // JstTxt
            // 
            this.JstTxt.AutoSize = true;
            this.JstTxt.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JstTxt.Location = new System.Drawing.Point(12, 9);
            this.JstTxt.Name = "JstTxt";
            this.JstTxt.Size = new System.Drawing.Size(174, 37);
            this.JstTxt.TabIndex = 0;
            this.JstTxt.Text = "Окно клиента";
            // 
            // Perspect
            // 
            this.Perspect.AutoSize = true;
            this.Perspect.Font = new System.Drawing.Font("Wide Latin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Perspect.Location = new System.Drawing.Point(15, 57);
            this.Perspect.Name = "Perspect";
            this.Perspect.Size = new System.Drawing.Size(79, 19);
            this.Perspect.TabIndex = 1;
            this.Perspect.Text = "Ну привет";
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 335);
            this.Controls.Add(this.Perspect);
            this.Controls.Add(this.JstTxt);
            this.Name = "FormUser";
            this.Text = "FormUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label JstTxt;
        private System.Windows.Forms.Label Perspect;
    }
}