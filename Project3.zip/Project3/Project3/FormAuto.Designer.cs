﻿namespace Project3
{
    partial class FormAuto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtBPassword = new System.Windows.Forms.TextBox();
            this.TxtBLogin = new System.Windows.Forms.TextBox();
            this.BtnReg = new System.Windows.Forms.Button();
            this.LblLog = new System.Windows.Forms.Label();
            this.LblPass = new System.Windows.Forms.Label();
            this.BtnEnter1 = new System.Windows.Forms.Button();
            this.BtnOKKK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtBPassword
            // 
            this.TxtBPassword.Location = new System.Drawing.Point(210, 309);
            this.TxtBPassword.Name = "TxtBPassword";
            this.TxtBPassword.Size = new System.Drawing.Size(100, 20);
            this.TxtBPassword.TabIndex = 3;
            this.TxtBPassword.TextChanged += new System.EventHandler(this.ForPassword_TextChanged);
            // 
            // TxtBLogin
            // 
            this.TxtBLogin.Location = new System.Drawing.Point(210, 253);
            this.TxtBLogin.Name = "TxtBLogin";
            this.TxtBLogin.Size = new System.Drawing.Size(100, 20);
            this.TxtBLogin.TabIndex = 4;
            // 
            // BtnReg
            // 
            this.BtnReg.Location = new System.Drawing.Point(229, 382);
            this.BtnReg.Name = "BtnReg";
            this.BtnReg.Size = new System.Drawing.Size(81, 23);
            this.BtnReg.TabIndex = 5;
            this.BtnReg.Text = "Регистрация";
            this.BtnReg.UseVisualStyleBackColor = true;
            this.BtnReg.Click += new System.EventHandler(this.BtnReg_Click);
            // 
            // LblLog
            // 
            this.LblLog.AutoSize = true;
            this.LblLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblLog.Location = new System.Drawing.Point(208, 230);
            this.LblLog.Name = "LblLog";
            this.LblLog.Size = new System.Drawing.Size(52, 20);
            this.LblLog.TabIndex = 6;
            this.LblLog.Text = "Login:";
            // 
            // LblPass
            // 
            this.LblPass.AutoSize = true;
            this.LblPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPass.Location = new System.Drawing.Point(208, 286);
            this.LblPass.Name = "LblPass";
            this.LblPass.Size = new System.Drawing.Size(78, 20);
            this.LblPass.TabIndex = 7;
            this.LblPass.Text = "Password";
            // 
            // BtnEnter1
            // 
            this.BtnEnter1.Location = new System.Drawing.Point(403, 283);
            this.BtnEnter1.Name = "BtnEnter1";
            this.BtnEnter1.Size = new System.Drawing.Size(75, 23);
            this.BtnEnter1.TabIndex = 8;
            this.BtnEnter1.Text = "Вход";
            this.BtnEnter1.UseVisualStyleBackColor = true;
            this.BtnEnter1.Click += new System.EventHandler(this.BtnEnter1_Click);
            // 
            // BtnOKKK
            // 
            this.BtnOKKK.Location = new System.Drawing.Point(229, 163);
            this.BtnOKKK.Name = "BtnOKKK";
            this.BtnOKKK.Size = new System.Drawing.Size(75, 23);
            this.BtnOKKK.TabIndex = 9;
            this.BtnOKKK.Text = "ОК";
            this.BtnOKKK.UseVisualStyleBackColor = true;
            this.BtnOKKK.Click += new System.EventHandler(this.BtnOKKK_Click);
            // 
            // FormAuto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(850, 493);
            this.Controls.Add(this.BtnOKKK);
            this.Controls.Add(this.BtnEnter1);
            this.Controls.Add(this.LblPass);
            this.Controls.Add(this.LblLog);
            this.Controls.Add(this.BtnReg);
            this.Controls.Add(this.TxtBLogin);
            this.Controls.Add(this.TxtBPassword);
            this.Name = "FormAuto";
            this.Text = "FormAuto";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Авторизация_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TxtBPassword;
        private System.Windows.Forms.TextBox TxtBLogin;
        private System.Windows.Forms.Button BtnReg;
        private System.Windows.Forms.Label LblLog;
        private System.Windows.Forms.Label LblPass;
        private System.Windows.Forms.Button BtnEnter1;
        private System.Windows.Forms.Button BtnOKKK;
    }
}

